//
//  ViewController.m
//  快速排序
//
//  Created by just do it on 16/6/20.
//  Copyright © 2016年 wnz. All rights reserved.
//

#import "ViewController.h"

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    NSMutableArray *array = [NSMutableArray arrayWithObjects:@100, @8, @6, @5, @1, @4, @7, @3, nil];
    for (int i = 0; i < array.count; i++ ) {
        [self quickSortTestWithArray:array withLeft:0 andRight:i];
    }
    NSLog(@"---%@", array);
    
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - 快速排序
- (void)quickSortTestWithArray:(NSMutableArray *)array withLeft:(int)left andRight:(int)right
{
    if (left >= right) {
        return;
    }
    
    int i = left;
    int j = right;
    int key = [array[left] intValue];
    
    while (i < j) {
        while (i < j && key <= [array[j] intValue]) {
            j--;
        }
        
        array[i] = array[j];
        
        while (i < j && key >= [array[i] intValue]) {
            i++;
        }
        
        array[j] = array[i];
    }
    
    array[i] = [NSNumber numberWithInt:key];
    
    [self quickSortTestWithArray:array withLeft:left andRight:i - 1];
    [self quickSortTestWithArray:array withLeft:i + 1 andRight:right];
}

//#pragma mark - 冒泡排序
//- (void)bubleSortWithArray:(NSMutableArray *)array
//{
//    int i, j, temp;
//    for (i = 0; i < array.count - 1; i++) {
//        for (j = 0; j < array.count - 1 - i; j++) {
//            if ([array[j] intValue] > [array[j + 1] intValue]) {
//                temp = [array[j] intValue];
//                array[j] = array[j + 1];
//                array[j + 1] = [NSNumber numberWithInt:temp];
//            }
//        }
//    }
//}

@end

