//
//  ViewController.m
//  选择排序
//
//  Created by just do it on 16/6/20.
//  Copyright © 2016年 wnz. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    NSMutableArray *array = [NSMutableArray arrayWithObjects:@100, @8, @6, @5, @1, @4, @7, @3, nil];
    [self sort:array];
    
}
//选择排序
-(void)sort:(NSMutableArray*)arr{
    for (int i = 0; i <arr.count; i++) {
        for (int j = i+1; j<arr.count; j++) {
            if ([arr[i] integerValue]>[arr[j]integerValue]) {
                int temp = [arr[i] integerValue];
                arr[i] = arr[j];
                arr[j] = [NSNumber numberWithInt:temp];
            }
            
            
        }
        
    }
    NSLog(@"选择排序后%@",arr);

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
