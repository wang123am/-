//
//  ViewController.m
//  冒泡排序
//
//  Created by just do it on 16/6/20.
//  Copyright © 2016年 wnz. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    NSMutableArray * mutableArr = [[NSMutableArray alloc]initWithObjects:@"1",@"100",@"16",@"20",@"590", nil];
    NSArray * arr =[self bubbleSort:mutableArr];
    NSLog(@"%@",arr);
    
}
//冒泡排序算法
-(NSArray*)bubbleSort:(NSMutableArray*)unsortArr{
    for (int i = 0 ; i < unsortArr.count; i ++) {
        for (int j = i+1; j <unsortArr.count; j++) {
            int a = [[unsortArr objectAtIndex:i] intValue];
      
            int b = [[unsortArr objectAtIndex:j] intValue];
          
            if (a > b)
            {
                [unsortArr replaceObjectAtIndex:i withObject:[NSString stringWithFormat:@"%d",b]];
                [unsortArr replaceObjectAtIndex:j withObject:[NSString stringWithFormat:@"%d",a]];
            }
         
        }
        
    }
    
    return unsortArr;
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
