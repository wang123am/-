//
//  ViewController.m
//  插入排序
//
//  Created by just do it on 16/6/20.
//  Copyright © 2016年 wnz. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    NSMutableArray *array = [NSMutableArray arrayWithObjects:@100, @8, @6, @5, @1, @4, @7, @3, nil];
    [self sort:array];
    
}
-(void)sort:(NSMutableArray*)arr{

    for (int i = 1; i < arr.count; i ++) {
        NSInteger temp = [arr[i] integerValue];
        for (int j = i -1; j >= 0&&temp <[arr[j] integerValue]; j--) {
            arr[j+1] = arr[j];
            arr[j] = [NSNumber numberWithInt:temp];
        }
        
        
    }
    NSLog(@"%@",arr);
    

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
